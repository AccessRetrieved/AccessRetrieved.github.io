Exes are dropped here by the release script.
